/**
 * Extensions to the {@link com.google.appengine.api.datastore} package related to overlay
 * Datastores.
 */
package com.google.appengine.api.labs.datastore.overlay;
